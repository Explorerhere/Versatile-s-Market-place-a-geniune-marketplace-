Versatile's Market place( a geniune marketplace)

created using next.js,tailwindcss,sanity.io,thirdweb,vercel

install all necessary nodule modules with command: npm install


deployed using vercel
